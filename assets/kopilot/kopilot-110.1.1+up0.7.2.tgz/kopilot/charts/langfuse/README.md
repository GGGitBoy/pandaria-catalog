# langfuse

![Version: 2.2.4](https://img.shields.io/badge/Version-2.2.4-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 4.77.0](https://img.shields.io/badge/AppVersion-4.77.0-informational?style=flat-square)

Open source LLM engineering platform - LLM observability, metrics, evaluations, prompt management.

**Homepage:** <https://langfuse.com/>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| langfuse | <contact@langfuse.com> | <https://langfuse.com/> |

## Source Code

* <https://github.com/langfuse/langfuse>
* <https://github.com/langfuse/langfuse-k8s>

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://groundhog2k.github.io/helm-charts/ | postgresql(postgres) | 1.6.3 |
| https://seaweedfs.github.io/seaweedfs/helm | s3(seaweedfs) | 4.23.0 |
| https://valkey-io.github.io/valkey-helm | redis(valkey) | 0.9.4 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| clickhouse.auth.existingSecret | string | `""` | Existing Secret holding the ClickHouse password. When set, auth.password is ignored. |
| clickhouse.auth.existingSecretKey | string | `""` | Key within existingSecret that contains the ClickHouse password. |
| clickhouse.auth.password | string | `""` | Password Langfuse uses to authenticate to ClickHouse. Leave empty to have the chart generate one. |
| clickhouse.auth.username | string | `"default"` | Username Langfuse uses to authenticate to ClickHouse. |
| clickhouse.cluster.affinity | object | `{}` | Affinity rules for ClickHouse pods. |
| clickhouse.cluster.enabled | bool | `true` | Enable ON CLUSTER DDL in Langfuse (CLICKHOUSE_CLUSTER_ENABLED). Disable only for an external non-clustered ClickHouse. |
| clickhouse.cluster.image.pullSecrets | list | `[]` | Image pull secrets for ClickHouse pods (`spec.podTemplate.imagePullSecrets` on the ClickHouseCluster CR), e.g. `[{name: my-registry-secret}]`. Required when pulling from a private registry. |
| clickhouse.cluster.image.repository | string | `"clickhouse/clickhouse-server"` | ClickHouse server image repository. |
| clickhouse.cluster.image.tag | string | `"26.8.36.3"` | ClickHouse server image tag. Keep aligned with the version recommended for Langfuse v4. |
| clickhouse.cluster.logger | object | `{}` | Operator logger settings for the ClickHouse server (`spec.settings.logger` on the ClickHouseCluster CR): `level`, `jsonLogs`, `logToFile`, `size`, `count`. clickhouse-operator 0.0.8+ defaults to `level: information`; older operators default to the very verbose `trace`, so set `level` explicitly if you run one. |
| clickhouse.cluster.nodeSelector | object | `{}` | Node selector for ClickHouse pods. |
| clickhouse.cluster.priorityClassName | string | `""` | PriorityClass for ClickHouse pods. |
| clickhouse.cluster.profileSettings | object | `{}` | Extra ClickHouse user profile settings mounted into users.xml. |
| clickhouse.cluster.replicas | int | `1` | Number of ClickHouse replicas. 1 is a valid single-pod cluster; 2+ requires Keeper enabled. |
| clickhouse.cluster.resources | object | `{"limits":{"memory":"4Gi"},"requests":{"cpu":"1","memory":"2Gi"}}` | CPU/memory for ClickHouse pods. Non-empty defaults avoid the operator's ~1Gi fallback that OOMs under load. |
| clickhouse.cluster.settings | object | `{}` | Extra ClickHouse server settings applied under the `<clickhouse>` config section. |
| clickhouse.cluster.storage.accessModes[0] | string | `"ReadWriteOnce"` |  |
| clickhouse.cluster.storage.className | string | `""` | StorageClass for ClickHouse PVCs. Leave empty to use the cluster default. |
| clickhouse.cluster.storage.size | string | `"100Gi"` | Persistent volume size for each ClickHouse pod. |
| clickhouse.cluster.tolerations | list | `[]` | Tolerations for ClickHouse pods. |
| clickhouse.clusterDomain | string | `"cluster.local"` | Kubernetes cluster domain suffix the operator uses to build in-cluster DNS names for ClickHouse pods (`spec.clusterDomain` on the ClickHouseCluster CR). Change only if your cluster does not use the default `cluster.local`. |
| clickhouse.crdCheck | bool | `true` | Require ClickHouse operator CRDs when deploy is true. Disable for offline helm template/GitOps diffs (or pass `--api-versions clickhouse.com/v1alpha1/ClickHouseCluster`). |
| clickhouse.database | string | `"default"` | ClickHouse database name Langfuse connects to. |
| clickhouse.deploy | bool | `true` | Deploy ClickHouse (ClickHouseCluster + KeeperCluster CRs) via the operator. Disable to use an external or self-managed ClickHouse. |
| clickhouse.host | string | `""` | ClickHouse hostname Langfuse connects to. Auto-set from the cluster Service when deploy is true; set explicitly for external ClickHouse. |
| clickhouse.httpPort | int | `8123` | HTTP port Langfuse uses to talk to ClickHouse. |
| clickhouse.keeper.affinity | object | `{}` | Affinity rules for Keeper pods. |
| clickhouse.keeper.clusterDomain | string | `"cluster.local"` | Kubernetes cluster domain suffix the operator uses to build in-cluster DNS names for Keeper pods (`spec.clusterDomain` on the KeeperCluster CR). Keep aligned with `clickhouse.clusterDomain`. |
| clickhouse.keeper.enabled | bool | `true` | Deploy a KeeperCluster alongside ClickHouse. Must stay enabled while clickhouse.deploy is true — the ClickHouseCluster CRD requires a keeperClusterRef even for a single replica. Run ClickHouse externally (clickhouse.deploy=false + clickhouse.host) to avoid Keeper. |
| clickhouse.keeper.image.pullSecrets | list | `[]` | Image pull secrets for Keeper pods (`spec.podTemplate.imagePullSecrets` on the KeeperCluster CR), e.g. `[{name: my-registry-secret}]`. Required when pulling from a private registry. |
| clickhouse.keeper.image.repository | string | `"clickhouse/clickhouse-keeper"` | ClickHouse Keeper image repository. |
| clickhouse.keeper.image.tag | string | `"26.8.36.3"` | ClickHouse Keeper image tag. Keep aligned with the ClickHouse server tag. |
| clickhouse.keeper.logger | object | `{}` | Operator logger settings for Keeper (`spec.settings.logger` on the KeeperCluster CR): `level`, `jsonLogs`, `logToFile`, `size`, `count`. clickhouse-operator 0.0.8+ defaults to `level: information`; older operators default to `trace`, which logs every Raft heartbeat and probe, so set `level` explicitly if you run one. |
| clickhouse.keeper.nodeSelector | object | `{}` | Node selector for Keeper pods. |
| clickhouse.keeper.priorityClassName | string | `""` | PriorityClass for Keeper pods. |
| clickhouse.keeper.replicas | int | `3` | Keeper replica count (must be odd: 1, 3, or 5). Use 3 for production HA. |
| clickhouse.keeper.resources | object | `{"limits":{"memory":"1Gi"},"requests":{"cpu":"250m","memory":"256Mi"}}` | CPU/memory requests and limits for Keeper pods. |
| clickhouse.keeper.settings | object | `{}` | Extra Keeper configuration merged with the operator-generated one (`spec.settings.extraConfig`), like `clickhouse.cluster.settings` for the server. |
| clickhouse.keeper.storage.accessModes[0] | string | `"ReadWriteOnce"` |  |
| clickhouse.keeper.storage.className | string | `""` | StorageClass for Keeper PVCs. Leave empty to use the cluster default. |
| clickhouse.keeper.storage.size | string | `"20Gi"` | Persistent volume size for each Keeper pod. |
| clickhouse.keeper.tolerations | list | `[]` | Tolerations for Keeper pods. |
| clickhouse.migration.autoMigrate | bool | `true` | Run ClickHouse schema migrations automatically when Langfuse starts. |
| clickhouse.migration.ssl | bool | `false` | Use SSL for ClickHouse schema migrations. |
| clickhouse.migration.url | string | `""` | ClickHouse migration URL (native TCP). Leave empty to derive from host/port when deploy is true. |
| clickhouse.nativePort | int | `9000` | Native TCP port Langfuse uses to talk to ClickHouse. |
| extraManifests | list | `[]` |  |
| fullnameOverride | string | `""` | Override the full name of the deployed resources, defaults to a combination of the release name and the name for the selector labels |
| langfuse.additionalEnv | list | `[]` | List of additional environment variables to be added to all langfuse deployments. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.additionalEnvFrom | list | `[]` | Secrets or ConfigMap of additional environment variables to be added to all langfuse deployments. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.affinity | object | `{}` | Affinity for all langfuse deployments |
| langfuse.aiFeatures | object | `{"apiKey":{"secretKeyRef":{"key":"","name":""},"value":""},"baseUrl":"","bedrockRegion":"","extraHeaders":"","inAppAgent":{"enabled":false,"mcp":{"useInternalWebUrl":false},"sandbox":{"egressNetworkConnectorArn":"","executionRoleArn":"","imageIdentifier":"","provider":"","region":""}},"model":"","projectId":"","provider":"","smallModel":"","useResponsesApi":false}` | Langfuse AI features: the in-app agent and Ask AI. One instance-wide Langfuse AI model powers both. Requires application version >= 4.24. Helm does not create AWS Lambda MicroVM resources; pass ARNs from Terraform or a manual AWS setup. See https://langfuse.com/self-hosting/configuration/langfuse-assistant |
| langfuse.aiFeatures.apiKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | LANGFUSE_AI_API_KEY. Required for anthropic and openai; rejected for bedrock, which authenticates through the AWS credential chain. Prefer secretKeyRef. |
| langfuse.aiFeatures.baseUrl | string | `""` | LANGFUSE_AI_BASE_URL. For openai, include `/v1`. |
| langfuse.aiFeatures.bedrockRegion | string | `""` | LANGFUSE_AI_AWS_BEDROCK_REGION |
| langfuse.aiFeatures.extraHeaders | string | `""` | LANGFUSE_AI_EXTRA_HEADERS as a JSON object string |
| langfuse.aiFeatures.inAppAgent.enabled | bool | `false` | Set to `true` to set LANGFUSE_IN_APP_AGENT_ENABLED on web and worker |
| langfuse.aiFeatures.inAppAgent.mcp.useInternalWebUrl | bool | `false` | Point the worker's MCP calls at the in-cluster web Service and allow that Host on web. Sets LANGFUSE_MCP_BASE_URL, so the externally resolvable NEXTAUTH_URL is left alone; the worker also builds email and Slack links from it. Requires application version >= 4.25, unlike the rest of this block; on 4.24 the worker ignores it and falls back to NEXTAUTH_URL. |
| langfuse.aiFeatures.inAppAgent.sandbox.egressNetworkConnectorArn | string | `""` | LANGFUSE_IN_APP_AGENT_SANDBOX_AWS_LAMBDA_MICROVM_EGRESS_NETWORK_CONNECTOR_ARN. Required with the lambda-microvm provider: without it AWS attaches its default INTERNET_EGRESS connector and sandboxed code reaches the public internet. |
| langfuse.aiFeatures.inAppAgent.sandbox.executionRoleArn | string | `""` | LANGFUSE_IN_APP_AGENT_SANDBOX_AWS_LAMBDA_MICROVM_EXECUTION_ROLE_ARN |
| langfuse.aiFeatures.inAppAgent.sandbox.imageIdentifier | string | `""` | LANGFUSE_IN_APP_AGENT_SANDBOX_AWS_LAMBDA_MICROVM_IMAGE_IDENTIFIER |
| langfuse.aiFeatures.inAppAgent.sandbox.provider | string | `""` | LANGFUSE_IN_APP_AGENT_SANDBOX_PROVIDER. `lambda-microvm` is the only accepted value; leave empty for Langfuse tools only. The application also has a development-only `dangerous-docker` provider, which is not usable in a deployed instance. |
| langfuse.aiFeatures.inAppAgent.sandbox.region | string | `""` | LANGFUSE_IN_APP_AGENT_SANDBOX_AWS_LAMBDA_MICROVM_REGION |
| langfuse.aiFeatures.model | string | `""` | LANGFUSE_AI_MODEL. Required whenever provider is set. |
| langfuse.aiFeatures.projectId | string | `""` | LANGFUSE_AI_FEATURES_PROJECT_ID for tracing AI feature runs on this instance |
| langfuse.aiFeatures.provider | string | `""` | LANGFUSE_AI_PROVIDER: bedrock, anthropic, or openai. Required to enable the AI features; there is no default. Must be set together with model. |
| langfuse.aiFeatures.smallModel | string | `""` | LANGFUSE_AI_SMALL_MODEL for supplementary calls such as conversation titles |
| langfuse.aiFeatures.useResponsesApi | bool | `false` | Set LANGFUSE_AI_USE_RESPONSES_API=true for the OpenAI Responses API |
| langfuse.allowV1Upgrade | bool | `false` | Allow helm upgrade that would replace leftover v1 Bitnami stores (CH STS, PG PVC, MinIO Deploy) with empty v2 volumes. Default false. The supported path is examples/upgrade-v1-to-v2 (in-place only when stores are external; otherwise a sibling v2 release). |
| langfuse.allowedOrganizationCreators | list | `[]` | EE: Langfuse allowed organization creators. See [documentation](https://langfuse.com/self-hosting/organization-creators) |
| langfuse.deployment.annotations | object | `{}` | Annotations for all langfuse deployments |
| langfuse.deployment.strategy | object | `{}` | Deployment strategy for all langfuse deployments (can be overridden by individual deployments) |
| langfuse.dnsConfig | object | `{}` | DNS configuration for all langfuse deployments |
| langfuse.encryptionKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | Encryption key for sensitive data (256 bits / 64 hex chars). Leave empty to auto-generate on first install (persisted in `<release>-app`); override with value/secretKeyRef to pin. Generate via `openssl rand -hex 32`. |
| langfuse.extraContainers | list | `[]` | Allows additional containers to be added to all langfuse deployments |
| langfuse.extraInitContainers | list | `[]` | Allows additional init containers to be added to all langfuse deployments |
| langfuse.extraLifecycle | object | `{}` | Allows additional lifecycle hooks to be added to all langfuse deployments |
| langfuse.extraVolumeMounts | list | `[]` | Allows additional volume mounts to be added to all langfuse deployments |
| langfuse.extraVolumes | list | `[]` | Allows additional volumes to be added to all langfuse deployments |
| langfuse.features.experimentalFeaturesEnabled | bool | `false` | Enable experimental features |
| langfuse.features.signUpDisabled | bool | `false` | Disable public sign up |
| langfuse.features.telemetryEnabled | bool | `true` | Whether or not to report basic usage statistics to a centralized server. |
| langfuse.gateway.connectionDrainTimeoutSeconds | int | `300` | [Beta] LANGFUSE_AI_GATEWAY_CONNECTION_DRAIN_TIMEOUT_SECONDS: how long the gateway drains in-flight requests after SIGTERM (1-300). On Kubernetes this is the only stream drain, so streams longer than this are cut on every rollout and scale-in. |
| langfuse.gateway.deployment.additionalLabels | object | `{}` | [Beta] Additional labels for the AI gateway deployment |
| langfuse.gateway.deployment.annotations | object | `{}` | [Beta] Annotations for the AI gateway deployment |
| langfuse.gateway.deployment.strategy | object | `{}` | [Beta] Deployment strategy for the AI gateway deployment. Overrides the global deployment strategy |
| langfuse.gateway.enabled | bool | `false` | [Beta] Set to `true` to deploy the Langfuse AI gateway. Web always gets `LANGFUSE_AI_GATEWAY_DEPLOYED` set to `"true"` or `"false"` to match, unless `additionalEnv` already sets it. The chart does not set web's `LANGFUSE_AI_GATEWAY_ENABLED` feature flag (web defaults it to `true`); set it through `additionalEnv` to turn the gateway features off. Requires a Langfuse release that has `LANGFUSE_AI_GATEWAY_DEPLOYED`. Also generates the gateway's service key and JWT private key into `<release>-app` unless provided. |
| langfuse.gateway.hpa.annotations | object | `{}` | [Beta] Annotations for the AI gateway HPA |
| langfuse.gateway.hpa.enabled | bool | `false` | [Beta] Set to `true` to enable HPA for the AI gateway pods |
| langfuse.gateway.hpa.maxReplicas | int | `2` | [Beta] The maximum number of replicas to use for the AI gateway pods |
| langfuse.gateway.hpa.minReplicas | int | `1` | [Beta] The minimum number of replicas to use for the AI gateway pods |
| langfuse.gateway.hpa.targetCPUUtilizationPercentage | int | `50` | [Beta] The target CPU utilization percentage for the AI gateway pods |
| langfuse.gateway.image.pullPolicy | string | `nil` | [Beta] The pull policy to use for the AI gateway pods. Using `langfuse.image.pullPolicy` if not set. |
| langfuse.gateway.image.pullSecrets | string | `nil` | [Beta] The pull secrets to use for the AI gateway pods. Using `langfuse.image.pullSecrets` if not set. |
| langfuse.gateway.image.repository | string | `"docker.langfuse.com/langfuse/ai-gateway"` | [Beta] The image repository to use for the AI gateway pods. |
| langfuse.gateway.image.tag | string | `nil` | [Beta] The tag to use for the AI gateway pods. Using `langfuse.image.tag` if not set. |
| langfuse.gateway.ingress.additionalLabels | object | `{}` | [Beta] Additional labels for the AI gateway ingress |
| langfuse.gateway.ingress.annotations | object | `{}` | [Beta] Annotations for the AI gateway ingress |
| langfuse.gateway.ingress.className | string | `""` | [Beta] The class name for the AI gateway ingress. Using `langfuse.ingress.className` if not set. |
| langfuse.gateway.ingress.enabled | bool | `false` | [Beta] Set to `true` to create an Ingress for the AI gateway |
| langfuse.gateway.ingress.hosts | list | `[]` | [Beta] Hostnames for the AI gateway ingress, e.g. `["gateway.langfuse.example.com"]`. Each host routes `/` to the gateway service. |
| langfuse.gateway.ingress.tls.enabled | bool | `false` | [Beta] Set to `true` to enable HTTPS on the AI gateway ingress |
| langfuse.gateway.ingress.tls.secretName | string | `""` | [Beta] The name of the TLS secret for the AI gateway hosts. Use a different secret than `langfuse.ingress.tls.secretName` when cert-manager issues it. |
| langfuse.gateway.jwt.keyId | string | `""` | [Beta] LANGFUSE_AI_GATEWAY_JWT_KEY_ID set on web. Optional; web defaults it to the RFC 7638 thumbprint of the public key. |
| langfuse.gateway.jwt.privateKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | [Beta] LANGFUSE_AI_GATEWAY_JWT_PRIVATE_KEY: ES256 (P-256) PEM private key (SEC1 or PKCS8) web signs ingestion tokens with. Leave empty to auto-generate when the gateway is enabled (persisted in `<release>-app`); override with value/secretKeyRef to pin. Generate via `openssl ecparam -name prime256v1 -genkey -noout`. |
| langfuse.gateway.jwt.publicKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | [Beta] LANGFUSE_AI_GATEWAY_JWT_PUBLIC_KEY: PEM public key matching `privateKey`. Optional; web derives it from the private key when unset. Requires `privateKey` to be provided. |
| langfuse.gateway.livenessProbe.failureThreshold | int | `3` | [Beta] Failure threshold for livenessProbe. |
| langfuse.gateway.livenessProbe.initialDelaySeconds | int | `5` | [Beta] Initial delay seconds for livenessProbe. |
| langfuse.gateway.livenessProbe.path | string | `"/health"` | [Beta] Path to check for liveness. Returns 200 while the process runs, including while draining. |
| langfuse.gateway.livenessProbe.periodSeconds | int | `10` | [Beta] Period seconds for livenessProbe. |
| langfuse.gateway.livenessProbe.successThreshold | int | `1` | [Beta] Success threshold for livenessProbe. |
| langfuse.gateway.livenessProbe.timeoutSeconds | int | `5` | [Beta] Timeout seconds for livenessProbe. |
| langfuse.gateway.pdb.create | bool | `true` | [Beta] Set to `true` to create a Pod Disruption Budget for the AI gateway pods |
| langfuse.gateway.pdb.maxUnavailable | string | `""` | [Beta] Maximum number of unavailable pods during disruptions. Cannot be set simultaneously with minAvailable. Defaults to 1 if neither is set. |
| langfuse.gateway.pdb.minAvailable | string | `""` | [Beta] Minimum number of available pods during disruptions. Cannot be set simultaneously with maxUnavailable. |
| langfuse.gateway.pod.additionalEnv | list | `[]` | [Beta] Additional environment variables for the AI gateway pods, e.g. the tuning knobs `LANGFUSE_AI_GATEWAY_MAX_REQUEST_BYTES`, `LANGFUSE_AI_GATEWAY_MEMORY_BUDGET_BYTES`, `LANGFUSE_AI_GATEWAY_MAX_EXECUTION_SECONDS`, and `LANGFUSE_AI_GATEWAY_STALL_TIMEOUT_SECONDS`. The global `langfuse.additionalEnv` does not apply. |
| langfuse.gateway.pod.additionalEnvFrom | list | `[]` | [Beta] Secrets or ConfigMaps of additional environment variables for the AI gateway pods. The global `langfuse.additionalEnvFrom` does not apply. |
| langfuse.gateway.pod.affinity | string | `nil` | [Beta] Affinity for the AI gateway pods. Overrides the global affinity |
| langfuse.gateway.pod.annotations | object | `{}` | [Beta] Annotations for the AI gateway pods |
| langfuse.gateway.pod.extraContainers | list | `[]` | [Beta] Additional containers for the AI gateway pods. The global `langfuse.extraContainers` do not apply. |
| langfuse.gateway.pod.extraInitContainers | list | `[]` | [Beta] Additional init containers for the AI gateway pods. The global `langfuse.extraInitContainers` do not apply. |
| langfuse.gateway.pod.extraVolumeMounts | list | `[]` | [Beta] Additional volume mounts for the AI gateway container. The global `langfuse.extraVolumeMounts` do not apply. |
| langfuse.gateway.pod.extraVolumes | list | `[]` | [Beta] Additional volumes for the AI gateway pods, e.g. a private CA bundle. The global `langfuse.extraVolumes` do not apply. |
| langfuse.gateway.pod.labels | object | `{}` | [Beta] Labels for the AI gateway pods |
| langfuse.gateway.pod.nodeSelector | string | `nil` | [Beta] Node selector for the AI gateway pods. Overrides the global nodeSelector |
| langfuse.gateway.pod.priorityClassName | string | `nil` | [Beta] PriorityClass for the AI gateway pods. Overrides the global priorityClassName |
| langfuse.gateway.pod.tolerations | string | `nil` | [Beta] Tolerations for the AI gateway pods. Overrides the global tolerations |
| langfuse.gateway.pod.topologySpreadConstraints | string | `nil` | [Beta] Topology spread constraints for the AI gateway pods. Overrides the global topologySpreadConstraints |
| langfuse.gateway.preStopSleepSeconds | int | `10` | [Beta] Seconds the preStop hook sleeps before SIGTERM, so the endpoint is removed from the Service and ingress while the gateway still accepts connections. Set to 0 to disable the hook. |
| langfuse.gateway.publicUrl | string | `""` | [Beta] LANGFUSE_AI_GATEWAY_PUBLIC_URL on web: the gateway base URL web shows users in the UI and setup snippets, e.g. `https://llm.example.com`. When empty and the gateway ingress is enabled with hosts, defaults to the first host, over `https` when `ingress.tls.enabled` is set or `langfuse.nextauth.url` is `https://` (TLS terminated in front of the ingress), else `http`. When empty without a gateway ingress, web derives `gateway.<host of nextauth.url>`. Requires a Langfuse release that supports `LANGFUSE_AI_GATEWAY_PUBLIC_URL` (older releases ignore it); a value already set in `additionalEnv` wins. |
| langfuse.gateway.readinessProbe.failureThreshold | int | `3` | [Beta] Failure threshold for readinessProbe. |
| langfuse.gateway.readinessProbe.initialDelaySeconds | int | `5` | [Beta] Initial delay seconds for readinessProbe. |
| langfuse.gateway.readinessProbe.path | string | `"/ready"` | [Beta] Path to check for readiness. Returns 503 while draining or when web is not configured. |
| langfuse.gateway.readinessProbe.periodSeconds | int | `5` | [Beta] Period seconds for readinessProbe. |
| langfuse.gateway.readinessProbe.successThreshold | int | `1` | [Beta] Success threshold for readinessProbe. |
| langfuse.gateway.readinessProbe.timeoutSeconds | int | `5` | [Beta] Timeout seconds for readinessProbe. |
| langfuse.gateway.replicas | string | `nil` | [Beta] Number of replicas to use if HPA is not enabled. Defaults to the global replicas |
| langfuse.gateway.resources | object | `{}` | [Beta] Resources for the AI gateway pods. Defaults to the global resources. Recommended: 1 CPU and a memory limit of at least the memory budget (LANGFUSE_AI_GATEWAY_MEMORY_BUDGET_BYTES, 1 GiB by default) plus 512 Mi, e.g. 2Gi. |
| langfuse.gateway.revisionHistoryLimit | string | `nil` | [Beta] Number of old ReplicaSets to retain to allow rollback. Defaults to the global revisionHistoryLimit |
| langfuse.gateway.service.additionalLabels | object | `{}` | [Beta] Additional labels for the AI gateway service |
| langfuse.gateway.service.annotations | object | `{}` | [Beta] Annotations for the AI gateway service |
| langfuse.gateway.service.port | int | `8080` | [Beta] The port the AI gateway listens on and the service exposes |
| langfuse.gateway.service.type | string | `"ClusterIP"` | [Beta] The type of service to use for the AI gateway |
| langfuse.gateway.serviceKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | [Beta] LANGFUSE_AI_GATEWAY_SERVICE_KEY: HMAC key shared by the gateway and web. Leave empty to auto-generate when the gateway is enabled (persisted in `<release>-app`); override with value/secretKeyRef to pin. |
| langfuse.gateway.telemetryShutdownTimeoutSeconds | int | `30` | [Beta] LANGFUSE_AI_GATEWAY_TELEMETRY_SHUTDOWN_TIMEOUT_SECONDS: how long the gateway flushes telemetry after the connection drain ends (1-300). |
| langfuse.gateway.terminationGracePeriodSeconds | int | `350` | [Beta] Termination grace period for the AI gateway pods. Must be greater than `preStopSleepSeconds` + `connectionDrainTimeoutSeconds` + `telemetryShutdownTimeoutSeconds`. |
| langfuse.gateway.webUrl | string | `""` | [Beta] LANGFUSE_AI_GATEWAY_WEB_URL: the Langfuse web URL the gateway calls for request resolution and telemetry. Defaults to the in-cluster web Service (`http://<fullname>-web.<namespace>.svc.cluster.local:<port>`). For an `http://` URL the chart sets `LANGFUSE_AI_GATEWAY_ALLOW_HTTP_WEB_URL=true` on the gateway. Plain HTTP is only meant for this internal in-cluster Service default, since web's responses carry provider API keys; an explicit `webUrl` that crosses a public network must be `https://` (for example `langfuse.nextauth.url`). |
| langfuse.image.pullPolicy | string | `"Always"` | The pull policy to use for all langfuse deployments. Can be overridden by the individual deployments. |
| langfuse.image.pullSecrets | list | `[]` | The pull secrets to use for all langfuse deployments. Can be overridden by the individual deployments. |
| langfuse.image.tag | string | `nil` | The image tag to use for all langfuse deployments. Can be overridden by the individual deployments. Falls back to appVersion if not set. |
| langfuse.ingress.additionalLabels | object | `{}` | Additional labels for the ingress resource |
| langfuse.ingress.annotations | object | `{}` | Annotations for the ingress resource |
| langfuse.ingress.className | string | `""` | The class name for the ingress resource |
| langfuse.ingress.enabled | bool | `false` | Set to `true` to enable the ingress resource |
| langfuse.ingress.hosts | list | `[]` | The hosts for the ingress resource |
| langfuse.ingress.tls.enabled | bool | `false` | Set to `true` to enable use HTTPS on the ingress |
| langfuse.ingress.tls.secretName | string | `""` | The name of the secret to use for TLS Key |
| langfuse.licenseKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | Langfuse EE license key. |
| langfuse.logging.format | string | `"text"` | Set the log format for the application (text or json) |
| langfuse.logging.level | string | `"info"` | Set the log level for the application (trace, debug, info, warn, error, fatal) |
| langfuse.nextauth.secret | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | NextAuth secret for JWT encryption and email token hashing. Leave empty to auto-generate on first install (persisted in `<release>-app`); override with value/secretKeyRef to pin. |
| langfuse.nextauth.url | string | `"http://localhost:3000"` | When deploying to production, set the `nextauth.url` value to the canonical URL of your site. |
| langfuse.nodeEnv | string | `"production"` | Node.js environment to use for all langfuse deployments |
| langfuse.nodeSelector | object | `{}` | Node selector for all langfuse deployments |
| langfuse.pod.annotations | object | `{}` | Annotations for all langfuse pods |
| langfuse.pod.labels | object | `{}` | Labels for all langfuse pods |
| langfuse.pod.topologySpreadConstraints | list | `[]` | Topology spread constraints for all langfuse pods |
| langfuse.podSecurityContext | object | `{}` | Pod security context for all langfuse deployments |
| langfuse.priorityClassName | string | `""` | PriorityClass for all langfuse deployments |
| langfuse.replicas | int | `1` | Number of replicas to use for all langfuse deployments. Can be overridden by the individual deployments |
| langfuse.resources | object | `{}` | Resources for all langfuse deployments. Can be overridden by the individual deployments |
| langfuse.revisionHistoryLimit | int | `10` | Number of old ReplicaSets to retain to allow rollback. Can be overridden by the individual deployments |
| langfuse.salt | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | Salt used to hash API keys. Leave empty to auto-generate on first install (persisted in `<release>-app`); override with value/secretKeyRef to pin. Generate via `openssl rand -base64 32`. |
| langfuse.securityContext | object | `{}` | Security context for all langfuse deployments |
| langfuse.serviceAccount.annotations | object | `{}` | Annotations for the service account |
| langfuse.serviceAccount.automountServiceAccountToken | bool | `true` | Whether to automount service account token in pods. Set to false to disable automatic mounting of the service account token. |
| langfuse.serviceAccount.create | bool | `true` | Whether to create a service account for all langfuse deployments |
| langfuse.serviceAccount.name | string | `""` | Override the name of the service account to use, discovered automatically if not set |
| langfuse.smtp.connectionUrl | string | `""` | SMTP connection URL. See [documentation](https://langfuse.com/self-hosting/transactional-emails) |
| langfuse.smtp.fromAddress | string | `""` | From address for emails. Required if connectionUrl is set. |
| langfuse.tolerations | list | `[]` | Tolerations for all langfuse deployments |
| langfuse.web.deployment.additionalLabels | object | `{}` | Additional labels for the langfuse web deployment |
| langfuse.web.deployment.annotations | object | `{}` | Annotations for the web deployment |
| langfuse.web.deployment.strategy | object | `{}` | Deployment strategy for the web deployment. Overrides the global deployment strategy |
| langfuse.web.hostAliases | list | `[]` | Adding records to /etc/hosts in the pod's network. |
| langfuse.web.hpa.annotations | object | `{}` | Annotations for the langfuse web HPA |
| langfuse.web.hpa.enabled | bool | `false` | Set to `true` to enable HPA for the langfuse web pods Note: When both KEDA and HPA are enabled, the deployment will fail. |
| langfuse.web.hpa.maxReplicas | int | `2` | The maximum number of replicas to use for the langfuse web pods |
| langfuse.web.hpa.minReplicas | int | `1` | The minimum number of replicas to use for the langfuse web pods |
| langfuse.web.hpa.targetCPUUtilizationPercentage | int | `50` | The target CPU utilization percentage for the langfuse web pods |
| langfuse.web.image.pullPolicy | string | `nil` | The pull policy to use for the langfuse web pods. Using `langfuse.image.pullPolicy` if not set. |
| langfuse.web.image.pullSecrets | string | `nil` | The pull secrets to use for the langfuse web pods. Using `langfuse.image.pullSecrets` if not set. |
| langfuse.web.image.repository | string | `"docker.langfuse.com/langfuse/langfuse"` | The image repository to use for the langfuse web pods. |
| langfuse.web.image.tag | string | `nil` | The tag to use for the langfuse web pods. Using `langfuse.image.tag` if not set. |
| langfuse.web.keda.containerName | string | `""` | Optional container name to target for metrics (leave empty to target all containers) |
| langfuse.web.keda.enabled | bool | `false` | Set to `true` to enable KEDA for the langfuse web pods Note: When both KEDA and HPA are enabled, the deployment will fail. |
| langfuse.web.keda.maxReplicas | int | `2` | The maximum number of replicas to use for the langfuse web pods |
| langfuse.web.keda.metricType | string | `"Utilization"` | The metric type for scaling (Utilization or AverageValue) |
| langfuse.web.keda.minReplicas | int | `1` | The minimum number of replicas to use for the langfuse web pods |
| langfuse.web.keda.pollingInterval | int | `30` | The polling interval in seconds for checking metrics |
| langfuse.web.keda.triggerType | string | `"cpu"` | The trigger type for scaling (cpu or memory) |
| langfuse.web.keda.value | string | `"50"` | The target utilization percentage for the langfuse web pods |
| langfuse.web.livenessProbe.failureThreshold | int | `3` | Failure threshold for livenessProbe. |
| langfuse.web.livenessProbe.initialDelaySeconds | int | `20` | Initial delay seconds for livenessProbe. |
| langfuse.web.livenessProbe.path | string | `"/api/public/health"` | Path to check for liveness. |
| langfuse.web.livenessProbe.periodSeconds | int | `10` | Period seconds for livenessProbe. |
| langfuse.web.livenessProbe.successThreshold | int | `1` | Success threshold for livenessProbe. |
| langfuse.web.livenessProbe.timeoutSeconds | int | `5` | Timeout seconds for livenessProbe. |
| langfuse.web.pdb.create | bool | `true` | Set to `true` to create a Pod Disruption Budget for the langfuse web pods |
| langfuse.web.pdb.maxUnavailable | string | `""` | Maximum number of unavailable pods during disruptions. Cannot be set simultaneously with minAvailable. Defaults to 1 if neither is set. |
| langfuse.web.pdb.minAvailable | string | `""` | Minimum number of available pods during disruptions. Cannot be set simultaneously with maxUnavailable. |
| langfuse.web.pod.additionalEnv | list | `[]` | List of additional environment variables to be added to all langfuse web pods. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.web.pod.additionalEnvFrom | list | `[]` | Secrets or ConfigMap of additional environment variables to be added to all langfuse web pods. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.web.pod.affinity | string | `nil` | Affinity for the web pods. Overrides the global affinity |
| langfuse.web.pod.annotations | object | `{}` | Annotations for the web pods |
| langfuse.web.pod.extraContainers | list | `[]` | Allows additional containers to be added to all langfuse web pods |
| langfuse.web.pod.labels | object | `{}` | Labels for the web pods |
| langfuse.web.pod.nodeSelector | string | `nil` | Node selector for the web pods. Overrides the global nodeSelector |
| langfuse.web.pod.priorityClassName | string | `nil` | PriorityClass for the web pods. Overrides the global priorityClassName |
| langfuse.web.pod.tolerations | string | `nil` | Tolerations for the web pods. Overrides the global tolerations |
| langfuse.web.pod.topologySpreadConstraints | string | `nil` | Topology spread constraints for the web pods. Overrides the global topologySpreadConstraints |
| langfuse.web.readinessProbe.failureThreshold | int | `3` | Failure threshold for readinessProbe. |
| langfuse.web.readinessProbe.initialDelaySeconds | int | `20` | Initial delay seconds for readinessProbe. |
| langfuse.web.readinessProbe.path | string | `"/api/public/ready"` | Path to check for readiness. |
| langfuse.web.readinessProbe.periodSeconds | int | `10` | Period seconds for readinessProbe. |
| langfuse.web.readinessProbe.successThreshold | int | `1` | Success threshold for readinessProbe. |
| langfuse.web.readinessProbe.timeoutSeconds | int | `5` | Timeout seconds for readinessProbe. |
| langfuse.web.replicas | string | `nil` | Number of replicas to use if HPA is not enabled. Defaults to the global replicas |
| langfuse.web.resources | object | `{}` | Resources for the langfuse web pods. Defaults to the global resources |
| langfuse.web.revisionHistoryLimit | string | `nil` | Number of old ReplicaSets to retain to allow rollback. |
| langfuse.web.service.additionalLabels | object | `{}` | Additional labels for the langfuse web application service |
| langfuse.web.service.annotations | object | `{}` | Annotations for the langfuse web application service |
| langfuse.web.service.externalPort | string | `nil` | The external port that will be exposed by the service. Falls back to `port` if not set. |
| langfuse.web.service.nodePort | string | `nil` | The node port to use for the langfuse web application |
| langfuse.web.service.port | int | `3000` | The port to use for the langfuse web application |
| langfuse.web.service.type | string | `"ClusterIP"` | The type of service to use for the langfuse web application |
| langfuse.web.vpa.controlledResources | list | `[]` | The resources to control for the langfuse web pods |
| langfuse.web.vpa.enabled | bool | `false` | Set to `true` to enable VPA for the langfuse web pods |
| langfuse.web.vpa.maxAllowed | object | `{}` | The maximum allowed resources for the langfuse web pods |
| langfuse.web.vpa.minAllowed | object | `{}` | The minimum allowed resources for the langfuse web pods |
| langfuse.web.vpa.updatePolicy.updateMode | string | `"Auto"` | The update policy mode for the langfuse web pods |
| langfuse.worker.deployment.additionalLabels | object | `{}` | Additional labels for the worker deployment |
| langfuse.worker.deployment.annotations | object | `{}` | Annotations for the worker deployment |
| langfuse.worker.deployment.strategy | object | `{}` | Deployment strategy for the worker deployment. Overrides the global deployment strategy |
| langfuse.worker.hostAliases | list | `[]` | Adding records to /etc/hosts in the worker pod's network. |
| langfuse.worker.hpa.annotations | object | `{}` | Annotations for the langfuse worker HPA |
| langfuse.worker.hpa.enabled | bool | `false` | Set to `true` to enable HPA for the langfuse worker pods Note: When both KEDA and HPA are enabled, the deployment will fail. |
| langfuse.worker.hpa.maxReplicas | int | `2` | The maximum number of replicas to use for the langfuse worker pods |
| langfuse.worker.hpa.minReplicas | int | `1` | The minimum number of replicas to use for the langfuse worker pods |
| langfuse.worker.hpa.targetCPUUtilizationPercentage | int | `50` | The target CPU utilization percentage for the langfuse worker pods |
| langfuse.worker.image.pullPolicy | string | `nil` | The pull policy to use for the langfuse worker pods. Using `langfuse.image.pullPolicy` if not set. |
| langfuse.worker.image.pullSecrets | string | `nil` | The pull secrets to use for the langfuse worker pods. Using `langfuse.image.pullSecrets` if not set. |
| langfuse.worker.image.repository | string | `"docker.langfuse.com/langfuse/langfuse-worker"` | The image repository to use for the langfuse worker pods |
| langfuse.worker.image.tag | string | `nil` | The tag to use for the langfuse worker pods. Using `langfuse.image.tag` if not set. |
| langfuse.worker.keda.containerName | string | `""` | Optional container name to target for metrics (leave empty to target all containers) |
| langfuse.worker.keda.enabled | bool | `false` | Set to `true` to enable KEDA for the langfuse worker pods Note: When both KEDA and HPA are enabled, the deployment will fail. |
| langfuse.worker.keda.maxReplicas | int | `2` | The maximum number of replicas to use for the langfuse worker pods |
| langfuse.worker.keda.metricType | string | `"Utilization"` | The metric type for scaling (Utilization or AverageValue) |
| langfuse.worker.keda.minReplicas | int | `1` | The minimum number of replicas to use for the langfuse worker pods |
| langfuse.worker.keda.pollingInterval | int | `30` | The polling interval in seconds for checking metrics |
| langfuse.worker.keda.triggerType | string | `"cpu"` | The trigger type for scaling (cpu or memory) |
| langfuse.worker.keda.value | string | `"50"` | The target utilization percentage for the langfuse worker pods |
| langfuse.worker.livenessProbe.failureThreshold | int | `3` | Failure threshold for livenessProbe. |
| langfuse.worker.livenessProbe.initialDelaySeconds | int | `20` | Initial delay seconds for livenessProbe. |
| langfuse.worker.livenessProbe.path | string | `"/api/health"` | Path to check for liveness. Append `?failIfQueueConsumptionStuck=true` to make the probe fail when the worker has stopped consuming all BullMQ queues. |
| langfuse.worker.livenessProbe.periodSeconds | int | `10` | Period seconds for livenessProbe. |
| langfuse.worker.livenessProbe.successThreshold | int | `1` | Success threshold for livenessProbe. |
| langfuse.worker.livenessProbe.timeoutSeconds | int | `5` | Timeout seconds for livenessProbe. |
| langfuse.worker.pdb.create | bool | `true` | Set to `true` to create a Pod Disruption Budget for the worker deployment |
| langfuse.worker.pdb.maxUnavailable | string | `""` | Maximum number of unavailable pods during disruptions. Cannot be set simultaneously with minAvailable. Defaults to 1 if neither is set. |
| langfuse.worker.pdb.minAvailable | string | `""` | Minimum number of available pods during disruptions. Cannot be set simultaneously with maxUnavailable. |
| langfuse.worker.pod.additionalEnv | list | `[]` | List of additional environment variables to be added to all langfuse worker pods. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.worker.pod.additionalEnvFrom | list | `[]` | Secrets or ConfigMap of additional environment variables to be added to all langfuse worker pods. See [documentation](https://langfuse.com/docs/deployment/self-host#configuring-environment-variables) for details. |
| langfuse.worker.pod.affinity | string | `nil` | Affinity for the worker pods. Overrides the global affinity |
| langfuse.worker.pod.annotations | object | `{}` | Annotations for the worker pods |
| langfuse.worker.pod.extraContainers | list | `[]` | Allows additional containers to be added to all langfuse worker pods |
| langfuse.worker.pod.labels | object | `{}` | Labels for the worker pods |
| langfuse.worker.pod.nodeSelector | string | `nil` | Node selector for the worker pods. Overrides the global nodeSelector |
| langfuse.worker.pod.priorityClassName | string | `nil` | PriorityClass for the worker pods. Overrides the global priorityClassName |
| langfuse.worker.pod.tolerations | string | `nil` | Tolerations for the worker pods. Overrides the global tolerations |
| langfuse.worker.pod.topologySpreadConstraints | string | `nil` | Topology spread constraints for the worker pods. Overrides the global topologySpreadConstraints |
| langfuse.worker.replicas | string | `nil` | Number of replicas to use if HPA is not enabled. Defaults to the global replicas |
| langfuse.worker.resources | object | `{}` | Resources for the langfuse worker pods. Defaults to the global resources |
| langfuse.worker.revisionHistoryLimit | string | `nil` | Number of old ReplicaSets to retain to allow rollback. |
| langfuse.worker.vpa.controlledResources | list | `[]` | The resources to control for the langfuse worker pods |
| langfuse.worker.vpa.enabled | bool | `false` | Set to `true` to enable VPA for the langfuse worker pods |
| langfuse.worker.vpa.maxAllowed | object | `{}` | The maximum allowed resources for the langfuse worker pods |
| langfuse.worker.vpa.minAllowed | object | `{}` | The minimum allowed resources for the langfuse worker pods |
| langfuse.worker.vpa.updatePolicy.updateMode | string | `"Auto"` | The update policy mode for the langfuse worker pods |
| nameOverride | string | `""` | Override the name for the selector labels, defaults to the chart name |
| postgresql.affinity | object | `{}` |  |
| postgresql.args | string | `""` | Additional database connection arguments |
| postgresql.auth.args | string | `""` | Additional database connection arguments |
| postgresql.auth.database | string | `"langfuse"` | Database name Langfuse uses. Created automatically by the sub-chart when deploy is true. |
| postgresql.auth.existingSecret | string | `""` | If you want to use an existing secret for the postgres password, set the name of the secret here. (`postgresql.auth.password` will be ignored and picked up from this secret). |
| postgresql.auth.password | string | `""` | Password Langfuse uses to connect to PostgreSQL. Leave empty to have the chart generate one (stored in a release-managed Secret). |
| postgresql.auth.secretKeys | object | `{"adminPasswordKey":"postgres-password","userPasswordKey":"password"}` | Keys in existingSecret: userPasswordKey for Langfuse; adminPasswordKey for the Postgres superuser when deploy is true. |
| postgresql.auth.username | string | `"langfuse"` | Username Langfuse uses to connect to PostgreSQL. Created automatically by the sub-chart when deploy is true. |
| postgresql.deploy | bool | `true` | Deploy PostgreSQL via the bundled groundhog2k/postgres sub-chart. Disable to use an external or managed Postgres. |
| postgresql.directUrl | string | `""` | If `postgresql.deploy` is set to false, Connection string of your Postgres database used for database migrations. Use this if you want to use a different user for migrations or use connection pooling on DATABASE_URL. For large deployments, configure the database user with long timeouts as migrations might need a while to complete. |
| postgresql.host | string | `""` | PostgreSQL host to connect to. If postgresql.deploy is true, this will be set automatically based on the release name. |
| postgresql.image.pullPolicy | string | `"IfNotPresent"` |  |
| postgresql.image.repository | string | `"postgres"` | Postgres image. Defaults to the upstream Docker Hub image (Apache 2.0 / PostgreSQL license). |
| postgresql.image.tag | string | `"18"` |  |
| postgresql.livenessProbe | object | `{}` | Liveness / readiness probe customisations (see groundhog2k/postgres docs). |
| postgresql.migration.autoMigrate | bool | `true` | Whether to run automatic migrations on startup |
| postgresql.nodeSelector | object | `{}` | Node selector / tolerations / affinity for the Postgres pod. |
| postgresql.podSecurityContext | object | `{"fsGroup":999}` | Pod security context. |
| postgresql.port | string | `nil` | Port of the postgres server to use. Defaults to 5432. |
| postgresql.readinessProbe | object | `{}` |  |
| postgresql.replicaCount | int | `1` | Number of replicas for the Postgres StatefulSet. Single-instance only — set to 0 to suspend. |
| postgresql.resources | object | `{}` | Resource limits/requests for the Postgres pod. Tune for your workload. |
| postgresql.securityContext | object | `{"runAsGroup":999,"runAsUser":999}` | Container security context. |
| postgresql.service.port | int | `5432` | Port the Postgres Service exposes. Must match `postgresql.port` (or the langfuse default 5432). |
| postgresql.service.type | string | `"ClusterIP"` |  |
| postgresql.settings | object | `{"existingSecret":"langfuse-postgresql-auth","superuserPassword":{}}` | Pass-through Postgres settings for the groundhog2k sub-chart. Usually left alone; helpers wire the chart-managed Secret automatically. |
| postgresql.settings.existingSecret | string | `"langfuse-postgresql-auth"` | Existing Secret for the superuser password (keys: POSTGRES_USER, POSTGRES_PASSWORD). Single source of truth for the chart-managed Secret's name — the chart creates the Secret under this exact name, so any release name works. Override it (together with userDatabase.existingSecret) when running two releases in one namespace. |
| postgresql.settings.superuserPassword | object | `{}` | Postgres superuser password. Auto-derived from the chart-managed Secret unless existingSecret is set. |
| postgresql.shadowDatabaseUrl | string | `""` | If your database user lacks the CREATE DATABASE permission, you must create a shadow database and configure the "SHADOW_DATABASE_URL". This is often the case if you use a Cloud database. Refer to the Prisma docs for detailed instructions. |
| postgresql.startupProbe | object | `{}` |  |
| postgresql.storage | object | `{"className":"","persistentVolumeClaimRetentionPolicy":{"whenDeleted":"Retain","whenScaled":"Retain"},"requestedSize":"20Gi"}` | PVC settings for the Postgres data volume. |
| postgresql.storage.className | string | `""` | StorageClass name. Leave empty to use the cluster's default. |
| postgresql.storage.persistentVolumeClaimRetentionPolicy | object | `{"whenDeleted":"Retain","whenScaled":"Retain"}` | Keep the PVC after the release is uninstalled. |
| postgresql.tolerations | list | `[]` |  |
| postgresql.userDatabase | object | `{"existingSecret":"langfuse-postgresql-auth","name":{},"password":{},"user":{}}` | Bootstrap the Langfuse database/user on first start. Empty name/user/password maps use defaults from auth.* via the chart-managed Secret. |
| postgresql.userDatabase.existingSecret | string | `"langfuse-postgresql-auth"` | Existing Secret for userDatabase credentials (keys: USERDB_USER, USERDB_PASSWORD, POSTGRES_DB). Must match settings.existingSecret when the chart manages the Secret (validated at render time). |
| redis.auth.aclConfig | string | `""` | Pass-through to valkey-helm: extra inline ACL config appended after `aclUsers`. |
| redis.auth.aclUsers | object | `{"default":{"permissions":"~* &* +@all"}}` | Valkey ACL users to create. Must include "default" when auth.enabled is true; `~* &* +@all` grants full access. |
| redis.auth.database | int | `0` |  |
| redis.auth.enabled | bool | `true` | Enable ACL-based authentication on the bundled Valkey sub-chart. |
| redis.auth.existingSecret | string | `""` | Existing Secret holding the Redis password. When set, auth.password is ignored and the chart-managed Secret is not created. |
| redis.auth.existingSecretPasswordKey | string | `""` | The key in the existing secret that contains the password. |
| redis.auth.password | string | `""` | Redis password Langfuse authenticates with. Leave empty to auto-generate; set null to disable auth. URL-encode special characters. |
| redis.auth.username | string | `"default"` | Redis username Langfuse authenticates with. Set null to omit from the connection string; created as an ACL user when deploy is true. |
| redis.auth.usersExistingSecret | string | `"langfuse-redis-auth"` | Valkey ACL users Secret (one key per username). Single source of truth for the chart-managed Secret's name — the chart creates the Secret under this exact name, so any release name works. Override when running two releases in one namespace. |
| redis.cluster.enabled | bool | `false` | Set to `true` to enable Redis Cluster mode. When enabled, you must set `redis.deploy` to `false` and provide cluster nodes. |
| redis.cluster.nodes | list | `[]` | List of Redis cluster nodes in the format "host:port". Example: ["redis-1:6379", "redis-2:6379", "redis-3:6379"] |
| redis.dataStorage | object | `{"accessModes":["ReadWriteOnce"],"className":"","enabled":true,"keepPvc":false,"requestedSize":"8Gi"}` | Persistence for the primary node. |
| redis.deploy | bool | `true` | Deploy Valkey via the bundled valkey-io/valkey sub-chart. Disable to use an external Redis or Valkey. |
| redis.host | string | `""` | Redis host to connect to. If redis.deploy is true, this will be set automatically based on the release name. |
| redis.image.pullPolicy | string | `"IfNotPresent"` |  |
| redis.image.registry | string | `"docker.io"` |  |
| redis.image.repository | string | `"valkey/valkey"` |  |
| redis.image.tag | string | `"8.0"` |  |
| redis.metrics.enabled | bool | `false` | Enable the bundled Valkey Prometheus exporter sidecar. |
| redis.podSecurityContext.fsGroup | int | `1000` |  |
| redis.podSecurityContext.runAsGroup | int | `1000` |  |
| redis.podSecurityContext.runAsUser | int | `1000` |  |
| redis.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| redis.port | int | `6379` | Redis port to connect to. |
| redis.replica | object | `{"enabled":false,"persistence":{"accessModes":["ReadWriteOnce"],"size":"8Gi","storageClass":""},"replicas":0,"service":{"enabled":true,"port":6379,"type":"ClusterIP"}}` | Valkey replication. Default standalone; set enabled and replicas for primary/replica (Langfuse always targets the primary). |
| redis.resources | object | `{}` | Resource limits/requests for the Valkey pods. |
| redis.sentinel.enabled | bool | `false` | Set to `true` to enable Redis Sentinel mode. Cannot be enabled simultaneously with cluster mode. When enabled, you must set `redis.deploy` to `false`. |
| redis.sentinel.existingSecret | string | `""` | If you want to use an existing secret for the sentinel password, set the name of the secret here. (`redis.sentinel.password` will be ignored and picked up from this secret). |
| redis.sentinel.existingSecretPasswordKey | string | `""` | The key in the existing secret that contains the sentinel password. |
| redis.sentinel.masterName | string | `""` | Name of the Redis Sentinel master. Required when `redis.sentinel.enabled` is `true`. |
| redis.sentinel.nodes | string | `""` | Comma-separated list of Redis Sentinel nodes in the format "host:port". Example: "sentinel-1:26379,sentinel-2:26379,sentinel-3:26379". Required when `redis.sentinel.enabled` is `true`. |
| redis.sentinel.password | string | `""` | Password for Redis Sentinel authentication (optional). |
| redis.sentinel.username | string | `""` | Username for Redis Sentinel authentication (optional). |
| redis.service.port | int | `6379` | Port the primary Valkey Service exposes. |
| redis.service.type | string | `"ClusterIP"` |  |
| redis.tls.caPath | string | `""` | Path to the CA certificate file for TLS verification (mounted into Langfuse pods). |
| redis.tls.certPath | string | `""` | Path to the client certificate file for mutual TLS authentication. |
| redis.tls.enabled | bool | `false` | Enable TLS for Langfuse↔Redis. When deploy is true, also enables TLS on the Valkey sub-chart. |
| redis.tls.keyPath | string | `""` | Path to the client private key file for mutual TLS authentication. |
| redis.valkeyConfig | string | `"maxmemory-policy noeviction\n"` | Pass-through to valkey-helm: contents of valkey.conf. This is the sub-chart's only config mechanism (it consumes no command-line flag values). Langfuse requires `maxmemory-policy noeviction` to avoid losing job data — validated at render time. |
| s3.accessKeyId | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 accessKeyId to use for all uploads. Can be overridden per upload type. |
| s3.allInOne.data.accessModes[0] | string | `"ReadWriteOnce"` |  |
| s3.allInOne.data.size | string | `"50Gi"` |  |
| s3.allInOne.data.storageClass | string | `""` |  |
| s3.allInOne.data.type | string | `"persistentVolumeClaim"` | Persistence for the SeaweedFS data directory. |
| s3.allInOne.enabled | bool | `true` |  |
| s3.allInOne.resources.limits.cpu | int | `2` |  |
| s3.allInOne.resources.limits.memory | string | `"2Gi"` |  |
| s3.allInOne.resources.requests.cpu | string | `"500m"` |  |
| s3.allInOne.resources.requests.memory | string | `"1Gi"` |  |
| s3.allInOne.s3.createBuckets | list | `[{"name":"langfuse"}]` | Buckets to create by the SeaweedFS post-install/post-upgrade hook. Must include every bucket Langfuse uses (`s3.bucket` and any per-upload-type overrides) — validated at render time. |
| s3.allInOne.s3.createBucketsHook.resources | object | `{}` |  |
| s3.allInOne.s3.enableAuth | bool | `true` |  |
| s3.allInOne.s3.enabled | bool | `true` |  |
| s3.allInOne.s3.existingConfigSecret | string | `"langfuse-s3-auth"` | SeaweedFS IAM config Secret. Single source of truth for the chart-managed Secret's name — the chart creates the Secret (from s3.auth) under this exact name, so any release name works. Override when running two releases in one namespace. |
| s3.allInOne.s3.port | int | `8333` |  |
| s3.allInOne.service.internalTrafficPolicy | string | `"Cluster"` |  |
| s3.allInOne.service.type | string | `"ClusterIP"` |  |
| s3.auth.existingSecret | string | `""` | Existing Secret for S3 access/secret keys (via rootUserSecretKey / rootPasswordSecretKey). |
| s3.auth.rootPassword | string | `""` | S3 secret access key Langfuse uses against the SeaweedFS gateway. Leave empty to have the chart generate one. |
| s3.auth.rootPasswordSecretKey | string | `""` | Key in the existing secret that contains the S3 secret access key. |
| s3.auth.rootUser | string | `"langfuse"` | Access key ID Langfuse uses to authenticate against the SeaweedFS S3 gateway. |
| s3.auth.rootUserSecretKey | string | `""` | Key in the existing secret that contains the S3 access key ID. |
| s3.batchExport.accessKeyId | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 accessKeyId to use for batch exports. |
| s3.batchExport.bucket | string | `""` | S3 bucket to use for batch exports. |
| s3.batchExport.enabled | bool | `true` | Enable batch export. |
| s3.batchExport.endpoint | string | `""` | S3 endpoint to use for batch exports. |
| s3.batchExport.forcePathStyle | string | `nil` | Whether to force path style on requests. Required for SeaweedFS / MinIO. |
| s3.batchExport.prefix | string | `""` | Prefix to use for batch exports within the bucket. |
| s3.batchExport.region | string | `""` | S3 region to use for batch exports. |
| s3.batchExport.secretAccessKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 secretAccessKey to use for batch exports. |
| s3.bucket | string | `"langfuse"` | Default S3 bucket for uploads (overridable per upload type). Auto-created on SeaweedFS when deploy is true. |
| s3.concurrency.reads | int | `50` | Maximum number of concurrent read operations to S3. Defaults to 50. |
| s3.concurrency.writes | int | `50` | Maximum number of concurrent write operations to S3. Defaults to 50. |
| s3.defaultBuckets | string | `"langfuse"` | Legacy default bucket list; first entry is used when neither s3.bucket nor a per-upload bucket is set. |
| s3.deploy | bool | `true` | Deploy SeaweedFS via the bundled seaweedfs sub-chart. Disable to use external S3-compatible storage. |
| s3.endpoint | string | `""` | S3 endpoint for uploads (overridable per upload type). Auto-set to the SeaweedFS Service when deploy is true. |
| s3.eventUpload.accessKeyId | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 accessKeyId to use for event uploads. |
| s3.eventUpload.bucket | string | `""` | S3 bucket to use for event uploads. |
| s3.eventUpload.endpoint | string | `""` | S3 endpoint to use for event uploads. |
| s3.eventUpload.forcePathStyle | string | `nil` | Whether to force path style on requests. Required for SeaweedFS / MinIO. |
| s3.eventUpload.prefix | string | `""` | Prefix to use for event uploads within the bucket. |
| s3.eventUpload.region | string | `""` | S3 region to use for event uploads. |
| s3.eventUpload.secretAccessKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 secretAccessKey to use for event uploads. |
| s3.filer.enabled | bool | `false` |  |
| s3.forcePathStyle | bool | `true` | Whether to force path style on requests. Required for SeaweedFS / MinIO. Can be overridden per upload type. |
| s3.gcs.credentials | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | GCS credentials JSON (or secretKeyRef). Falls back to the pod's environment/service account credentials if unset. |
| s3.image.registry | string | `""` | SeaweedFS image registry. Empty pulls from Docker Hub. `global.imageRegistry` takes precedence when set. |
| s3.image.repository | string | `""` | SeaweedFS image repository. Empty uses the sub-chart default `chrislusf/seaweedfs`. |
| s3.image.tag | string | `""` | SeaweedFS image tag. Empty uses the sub-chart appVersion (`4.23` for seaweedfs 4.23.0). |
| s3.master.enabled | bool | `false` |  |
| s3.mediaUpload.accessKeyId | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 accessKeyId to use for media uploads. |
| s3.mediaUpload.bucket | string | `""` | S3 bucket to use for media uploads. |
| s3.mediaUpload.downloadUrlExpirySeconds | int | `3600` | Expiry time for download URLs. Defaults to 1 hour. |
| s3.mediaUpload.enabled | bool | `true` | Enable media uploads. |
| s3.mediaUpload.endpoint | string | `""` | S3 endpoint to use for media uploads. |
| s3.mediaUpload.forcePathStyle | string | `nil` | Whether to force path style on requests. Required for SeaweedFS / MinIO. |
| s3.mediaUpload.maxContentLength | int | `1000000000` | Maximum content length for media uploads. Defaults to 1GB. |
| s3.mediaUpload.prefix | string | `""` | Prefix to use for media uploads within the bucket. |
| s3.mediaUpload.region | string | `""` | S3 region to use for media uploads. |
| s3.mediaUpload.secretAccessKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 secretAccessKey to use for media uploads. |
| s3.region | string | `"auto"` | S3 region for uploads (overridable per upload type). |
| s3.s3.enabled | bool | `false` |  |
| s3.secretAccessKey | object | `{"secretKeyRef":{"key":"","name":""},"value":""}` | S3 secretAccessKey to use for all uploads. Can be overridden per upload type. |
| s3.storageProvider | string | `"s3"` | Object storage provider for Langfuse uploads: s3 (default), azure, or gcs. |
| s3.volume.enabled | bool | `false` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
